package application;


import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LevelFrame extends JFrame implements ActionListener {

   JPanel LevelPanel;
   JComboBox<String> levelbox;
   String level_list[] = { "Hell", "Normal", "Easy" };
   JLabel level_print;
   JButton startButton = new JButton();
   JButton questionButton = new JButton();
   String selected_level = "Hell";

   public LevelFrame() {
      setSize(500, 650);

      // getContentPane().setBackground(Color.orange); -> �Ƹ� �гο� ������ �ȳ���..
      setResizable(false);
      setLocationRelativeTo(null); // ������ġ�� ��ġ����
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      // LevelPanel ����
      LevelPanel = new JPanel();
      LevelPanel.setBackground(Color.orange); // ���� ����
      LevelPanel.setLayout(null);

      JLabel Title = new JLabel();
      ImageIcon titleIcon = new ImageIcon("src/image/SelectTitle.png");
      Title.setIcon(titleIcon);
      Title.setBounds(40,60,420,160);
      LevelPanel.add(Title);
      
      // Combobox ����
      levelbox = new JComboBox(level_list);
      level_print = new JLabel("LEVEL : CHOOSE LEVEL");

      levelbox.setBounds(180, 280, 120, 50); // combobox location
      level_print.setBounds(180, 340, 200, 35); // level_print location

      LevelPanel.add(levelbox);
      LevelPanel.add(level_print);

      ImageIcon questionIcon = new ImageIcon("src/image/questionIcon.png");

      questionButton.setIcon(questionIcon);
      questionButton.setBounds(400,500,100,100); // ��ư�� ��ġ
      questionButton.addActionListener(this);
      questionButton.setBorderPainted(false);
      questionButton.setFocusPainted(false);
      questionButton.setContentAreaFilled(false);
      LevelPanel.add(questionButton);

      
      // ���� ȭ�� �����ư ����
      ImageIcon normalIcon = new ImageIcon("src/image/startbutton2.png");
      ImageIcon rolloverIcon = new ImageIcon("src/image/startbutton.png");
      ImageIcon pressedIcon = new ImageIcon("src/image/startbutton2.png");

      startButton.setIcon(normalIcon); // �Ϲ����� ����
      startButton.setRolloverIcon(rolloverIcon);
      startButton.setPressedIcon(pressedIcon);
      startButton.setBounds(160,440,160,160); // ��ư�� ��ġ
      startButton.addActionListener(this);
      startButton.setBorderPainted(false);
      startButton.setFocusPainted(false);
      startButton.setContentAreaFilled(false);
      LevelPanel.add(startButton);

      add(LevelPanel);

      levelbox.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            selected_level = levelbox.getSelectedItem().toString();
            level_print.setText("LEVEL : " + selected_level);
         }
      });
      

      setVisible(true);
   }

   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == startButton) {
         this.setVisible(false);
         this.dispose(); // �ش������Ӹ�����
         new GameFrame(selected_level); // GameFrame���� �Ѿ!
      }
      else if(e.getSource() == questionButton) {
         new HowtoPlay();
      }
   }
}