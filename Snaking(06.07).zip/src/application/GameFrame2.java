package application;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class GameFrame2 extends JFrame implements ActionListener{

 JButton bt_AnotherGame;
 JButton bt_Exit;

 GameFrame2(){
    
    super("RESET");
    setLayout(new FlowLayout());
    JPanel Reset = new JPanel();
    //Reset.setLayout(null);
   ///Reset.setTitle("RESET");

   //  setUndecorated(true);
  //  setResizable(false);
   // Reset.setLayout(null);
     setBounds(GamePanel.SCREEN_WIDTH/2, GamePanel.SCREEN_HEIGHT/2-100, 300, 200); 
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
     bt_AnotherGame = new JButton("RESET");
     bt_AnotherGame.setFont(new Font("INK FREE", 0, 30));
     bt_AnotherGame.setBounds(GamePanel.SCREEN_WIDTH/4, 1, 1000, 200); //��ġ x,y, ���� ����
     bt_AnotherGame.addActionListener(this);
  
     bt_Exit = new JButton("EXIT");
     bt_Exit.setFont(new Font("INK FREE", 0, 30));
     bt_Exit.setBounds(GamePanel.SCREEN_WIDTH/4, 300, 1000, 200); //��ġ x,y, ���� ����
     bt_Exit.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
           System.exit(0);
        }
     });
  
  Reset.add(bt_AnotherGame);
  Reset.add(bt_Exit);

  add(Reset);
  setVisible(true);
  
 }

 @Override
 public void actionPerformed(ActionEvent e) {
  if(e.getSource()==bt_AnotherGame) {
	  this.setVisible(false);
      this.dispose(); //�ش������Ӹ�����
      new LevelFrame(); //������
  }
 }
}