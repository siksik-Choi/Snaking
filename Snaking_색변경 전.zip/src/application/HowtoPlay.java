package application;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HowtoPlay extends JFrame implements ActionListener {

   JPanel ExplainPanel;
   String str = "<html><h1>방향키를 움직여서<br>사과를 먹어보세요!\r</h1><br>"
         + "뱀의 머리가 화면의 가장자리에 닿거나, 자신의 몸과 충돌하면 게임이 끝납니다.\r\n"
         + "파란색 사과는 먹으면 속도가 빨라지고 10점을 획득합니다.\r<br>"
         + "핑크색 사과는 먹으면 속도가 느려지고 1점을 획득합니다.\r<br>"
         + "그 외의 다양한 색깔의 사과는 5점씩 점수를 획득합니다.\r<br>"
         + "\r<br>"
         + "난이도가 올라갈수록 파란색 사과가 더 자주 등장합니다.\r<br>"
         + "행운을 빕니다. Good Luck! 😆 </html>";
   
   JLabel ExplainLabel;
   JButton startButton = new JButton();

   
   public HowtoPlay() {
      setSize(500, 650);

      setResizable(false);
      setLocationRelativeTo(null); // 절대위치로 위치조정
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
      ExplainPanel = new JPanel();
      ExplainPanel.setBackground(new Color(44, 95, 45)); // 배경색 선택
      ExplainPanel.setLayout(null);
      
      ExplainLabel = new JLabel(str);
      ExplainLabel.setBounds(80,0,350,300);
      ExplainPanel.add(ExplainLabel);
      
      ImageIcon normalIcon = new ImageIcon("src/image/startbutton2.png");
      ImageIcon rolloverIcon = new ImageIcon("src/image/startbutton.png");
      ImageIcon pressedIcon = new ImageIcon("src/image/startbutton2.png");

      startButton.setIcon(normalIcon); // 일반적인 상태
      startButton.setRolloverIcon(rolloverIcon);
      startButton.setPressedIcon(pressedIcon);
      startButton.setBounds(150,380,160,160); // 버튼의 위치
      startButton.addActionListener(this);
      startButton.setBorderPainted(false);
      startButton.setFocusPainted(false);
      startButton.setContentAreaFilled(false);
      ExplainPanel.add(startButton);

      
      add(ExplainPanel);

      setVisible(true);
      
      

   }
   
   public void actionPerformed(ActionEvent e) {
      if (e.getSource() == startButton) {
         this.setVisible(false);
         this.dispose(); // 해당프레임만종료
      }
   }
}