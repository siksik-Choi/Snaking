package application;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class Ranking extends JFrame implements ActionListener {

    private final int X_RANK = 80;
    private final int X_NAME = 280;
    private final int X_SCORE = 490;
    private final int Y = 75;
    private final int WIDTH_LABEL = 150;
    private final int HEIGHT_LABEL = 50;

    JButton bt_AnotherGame = new JButton();
    JButton bt_Quit = new JButton();

    private JLabel labelRank, labelName, labelScore;

    private ArrayList ls = new ArrayList();
    
    Ranking() {
        setTitle("Eat Coin - Ranking");
        getContentPane().setBackground(Color.black);

        //setUndecorated(true);
        setResizable(false);
        setLayout(null);
        setBounds(500-GamePanel.SCREEN_WIDTH/16, 200-GamePanel.SCREEN_HEIGHT/4, GamePanel.SCREEN_WIDTH/2, GamePanel.SCREEN_HEIGHT);
        
        ImageIcon resetIcon = new ImageIcon("src/Image/reset.png");
        bt_AnotherGame.setIcon(resetIcon);
        bt_AnotherGame.setRolloverIcon(resetIcon);
        bt_AnotherGame.setPressedIcon(resetIcon);
        bt_AnotherGame.setBounds(50, 600, 100, 100); // ��ư�� ��ġ
        bt_AnotherGame.addActionListener(this);
        bt_AnotherGame.setBorderPainted(false);
        bt_AnotherGame.setFocusPainted(false);
        bt_AnotherGame.setContentAreaFilled(false);
      //StartPanel.add(bt_AnotherGame);
        
        ImageIcon exitIcon = new ImageIcon("src/Image/exit.png");
        bt_Quit.setIcon(exitIcon);
        bt_Quit.setRolloverIcon(exitIcon);
        bt_Quit.setPressedIcon(exitIcon);
        bt_Quit.setBounds(500, 600, 100, 100); // ��ư�� ��ġ
        bt_Quit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        bt_Quit.setBorderPainted(false);
        bt_Quit.setFocusPainted(false);
        bt_Quit.setContentAreaFilled(false);

        printRanking();
        add(bt_AnotherGame);
        add(bt_Quit);
        setVisible(true);
    }

    private void printRanking() {
        printRankingTitle();
        printActualRanking();
    }

    private void printRankingTitle() {
        labelRank = new JLabel("RANK");
        labelRank.setFont(new Font("Britannic", Font.BOLD, 40));
        labelRank.setForeground(Color.white);
        labelRank.setBounds(X_RANK-20, Y, WIDTH_LABEL, HEIGHT_LABEL);
        add(labelRank);

        labelName = new JLabel("NAME");
        labelName.setFont(new Font("Britannic", Font.BOLD, 40));
        labelName.setForeground(Color.white);
        labelName.setBounds(X_NAME-20, Y, WIDTH_LABEL, HEIGHT_LABEL);
        add(labelName);

        labelScore = new JLabel("SCORE");
        labelScore.setFont(new Font("Britannic", Font.BOLD, 40));
        labelScore.setForeground(Color.white);
        labelScore.setBounds(X_SCORE-20, Y, WIDTH_LABEL, HEIGHT_LABEL);
        add(labelScore);

    }

    private void printActualRanking() {
        try (
                FileReader fr = new FileReader("test.txt");
                BufferedReader br = new BufferedReader(fr);
        ) {
            String readLine = null;
            while ((readLine = br.readLine()) != null) { //�����̷�������?
                ls.add(readLine);
            }
        } catch (IOException e) {
        }


        ArrayList<Integer> lsScore = new ArrayList<Integer>();

        for (int i = 1; i <= ls.size() / 3; i++) {
            lsScore.add(Integer.valueOf((String) ls.get(3 * i - 2)));
        }
        Collections.sort(lsScore); //����

        ArrayList<String> lsScore2 = new ArrayList<String>();
        for (int i = 0; i < lsScore.size(); i++) { //intŸ���� isScore�� �ٽ� String����
            lsScore2.add(String.valueOf(lsScore.get(i)));
        }
        
        int rank = 0;
        for (int i = lsScore2.size(); i > lsScore2.size()-10; i--) { //
            int x = ls.indexOf(lsScore2.get(i - 1)); //ls�� �ε����� 1, 4,7..ã��
            rank++;
            callAllGen(x, rank);
        }
        
    }

    private void callAllGen(int x, int rank) { // x�� ���ھ ���� ������� �־������
        // y�� x�� ������������� 1~n���� for������ �־��� -> callAllGen�޼ҵ���°�����ŭ �Ȱ��ڴ�
        genName(x - 1, rank);
        genScore(x, rank);
        //genScoreR(x + 1, rank);
        genRank(Integer.toString(rank), rank);
    }

    private void genRank(String number, int rank) {
        labelRank = new JLabel(number);
        labelRank.setFont(new Font("Britannic", Font.BOLD, 20));
        labelRank.setForeground(Color.white);
        labelRank.setBounds(X_RANK, Y + 35 * rank, WIDTH_LABEL, HEIGHT_LABEL);
        add(labelRank);
    }

    private void genName(int index, int rank) {
        labelName = new JLabel((String) ls.get(index));
        labelName.setFont(new Font("Britannic", Font.BOLD, 20));
        labelName.setForeground(Color.white);
        labelName.setBounds(X_NAME, Y + 35 * rank, WIDTH_LABEL, HEIGHT_LABEL);
        add(labelName);
    }

    private void genScore(int index, int rank) {
        labelScore = new JLabel((String) ls.get(index));
        labelScore.setFont(new Font("Britannic", Font.BOLD, 20));
        labelScore.setForeground(Color.white);
        labelScore.setBounds(X_SCORE, Y + 35 * rank, WIDTH_LABEL, HEIGHT_LABEL);
        add(labelScore);
    }

    private void reset() {
        this.setVisible(false);
        this.dispose(); //�ش������Ӹ�����
        new StartPanel(); //������
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        reset();
    }
}