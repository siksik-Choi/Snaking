package application;

import javax.swing.JButton;
import javax.swing.JFrame;

public class GameFrame extends JFrame{

	GameFrame(String level){
			
		System.out.printf("%s\n", level);
		
		this.add(new GamePanel(level));
		this.setTitle("Snake");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
		this.setLocationRelativeTo(null);
		
	}
}