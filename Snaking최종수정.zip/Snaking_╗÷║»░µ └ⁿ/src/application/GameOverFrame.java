package application;


import javax.swing.*;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/*class USER {
   String name;
   int score;
}*/
class GameOverFrame extends JFrame implements ActionListener {

   // USER user;
    private JButton bt_OK;
    private JTextField tf;
    private JLabel label1;
    private String namePlayer;

    static int SCORE;
    static int SCORE_REPAINT; // ������Ʈ �� Ƚ���� ������ Ȱ���ϱ��..

    GameOverFrame() {
        setTitle("SnaKing Game Over");
       // setUndecorated(true);
        setResizable(false);
        setLayout(null);
        setBounds(GamePanel.SCREEN_WIDTH/2-125, GamePanel.SCREEN_HEIGHT/2-100, 500, 200); 
        
        label1 = new JLabel();
        label1.setText("Enter your name!");
        label1.setBounds(190,30,100,20);
        label1.setHorizontalAlignment(JLabel.CENTER);
       // label1.setFont(new Font(null, 0, 10));
        add(label1);

        
        tf = new JTextField(20);
        tf.setBounds(250-120, 100-40, 180, 30);
        tf.addActionListener(this);


        bt_OK = new JButton("OK");
        bt_OK.setFont(new Font(null, 0, 10));
        bt_OK.setBounds(310, 100-40, 50, 30);
        bt_OK.addActionListener(this);

        add(tf);
        add(bt_OK);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //user.name = tf.getText();
       namePlayer = tf.getText();
       try (
                FileWriter fw = new FileWriter("test.txt", true);
                BufferedWriter bw = new BufferedWriter(fw);
        ) {
            bw.write(namePlayer);
            bw.newLine();
            //user.score = SCORE;
            bw.write(Integer.toString(SCORE));
            bw.newLine();
            bw.write(Integer.toString(SCORE_REPAINT));
            bw.newLine();
            bw.flush();
        } catch (IOException ie) {
            System.out.println(ie);
        }
       this.setVisible(false);
       this.dispose(); // �ش������Ӹ�����
       
        new Ranking();
    }

}
