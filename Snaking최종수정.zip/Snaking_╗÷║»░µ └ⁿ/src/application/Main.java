package application;


public class Main {

	public static final int SCREEN_WIDTH = 500;
	public static final int SCREEN_HEIGHT = 650;
	
	public static void main(String[] args) {
		new StartPanel();
	}
	
}

